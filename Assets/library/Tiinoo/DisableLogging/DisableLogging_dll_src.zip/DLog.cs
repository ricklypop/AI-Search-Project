﻿using System;
using System.Collections;
using Tiinoo.DisableLogging;

namespace UnityEngine
{
	public static class DLog
	{
		public static Color DEFAULT_COLOR = Color.clear;
		private static string STR_NULL = "Null";
		
		public static bool enableLogInfo = true;
		public static bool enableLogWarning = true;
		public static bool enableLogError = true;

		public static void Log(string message)
		{
			LogImpl(LogType.Log, message, DEFAULT_COLOR, null);
		}

		public static void Log(string message, UnityEngine.Object context)
		{
			LogImpl(LogType.Log, message, DEFAULT_COLOR, context);
		}

		public static void Log(string message, Color color)
		{
			LogImpl(LogType.Log, message, color, null);
		}
		
		public static void Log(string message, Color color, UnityEngine.Object context)
		{
			LogImpl(LogType.Log, message, color, context);
		}
		
		public static void LogWarning(string message)
		{
			LogImpl(LogType.Warning, message, DEFAULT_COLOR, null);
		}

		public static void LogWarning(string message, UnityEngine.Object context)
		{
			LogImpl(LogType.Warning, message, DEFAULT_COLOR, context);
		}

		public static void LogWarning(string message, Color color)
		{
			LogImpl(LogType.Warning, message, color, null);
		}
		
		public static void LogWarning(string message, Color color, UnityEngine.Object context)
		{
			LogImpl(LogType.Warning, message, color, context);
		}
		
		public static void LogError(string message)
		{
			LogImpl(LogType.Error, message, DEFAULT_COLOR, null);
		}

		public static void LogError(string message, UnityEngine.Object context)
		{
			LogImpl(LogType.Error, message, DEFAULT_COLOR, context);
		}

		public static void LogError(string message, Color color)
		{
			LogImpl(LogType.Error, message, color, null);
		}
		
		public static void LogError(string message, Color color, UnityEngine.Object context)
		{
			LogImpl(LogType.Error, message, color, context);
		}

		public static void LogException(Exception e)
		{
			LogImpl(LogType.Error, e.ToString(), DEFAULT_COLOR, null);
		}

		public static void LogException(Exception e, UnityEngine.Object context)
		{
			LogImpl(LogType.Error, e.ToString(), DEFAULT_COLOR, context);
		}

		public static void LogException(Exception e, Color color)
		{
			LogImpl(LogType.Error, e.ToString(), color, null);
		}

		public static void LogException(Exception e, Color color, UnityEngine.Object context)
		{
			LogImpl(LogType.Error, e.ToString(), color, context);
		}
		
		private static void LogImpl(LogType logType, string message, Color color, UnityEngine.Object context)
		{
			if (!CanLog(logType))
			{
				return;
			}
			
			if (message == null)
			{
				message = STR_NULL;
			}
			
			LogToConsole.LogImpl(logType, message, color, context);
		}
		
		private static bool CanLog(LogType logType)
		{
			if (!enableLogInfo && logType == LogType.Log)
			{
				return false;
			}
			
			if (!enableLogWarning && logType == LogType.Warning)
			{
				return false;
			}
			
			if (!enableLogError && logType == LogType.Error)
			{
				return false;
			}
			
			if (!enableLogError && logType == LogType.Exception)
			{
				return false;
			}
			
			return true;
		}
	}
}

