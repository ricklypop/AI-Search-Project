﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

namespace Tiinoo.DisableLogging
{
	internal static class LogToConsole 
	{
		private static Dictionary<Color, string> m_hexColorDict;	// Color:color, string:hexColor
		
		private static Dictionary<Color, string> HexColorDict
		{
			get
			{
				if (m_hexColorDict == null) 
				{ 
					InitHexColorDict();
				}
				return m_hexColorDict;
			}
		}

		internal static void LogImpl(LogType logType, string message, Color color, UnityEngine.Object context)
		{
			if (color != DLog.DEFAULT_COLOR)
			{
				string hexColor = null;
				HexColorDict.TryGetValue(color, out hexColor);
				if (string.IsNullOrEmpty(hexColor))
				{
					hexColor = ColorToHexColor(color);
				}
				message = Colored(message, hexColor);
			}
			
			switch (logType)
			{
			case LogType.Log:
				Debug.Log(message, context); 
				break;
				
			case LogType.Warning:
				Debug.LogWarning(message, context);
				break;
				
			default:
				Debug.LogError(message, context);
				break;
			}
		}
		
		private static void InitHexColorDict()
		{
			Color[] colors = new Color[]{
				Color.red, Color.yellow, Color.green, Color.blue, 
				Color.white, Color.black, Color.gray, Color.grey, 
				Color.cyan, Color.magenta, 
			};
			
			m_hexColorDict = new Dictionary<Color, string>(); 
			foreach (Color color in colors)
			{
				string hexColor = ColorToHexColor(color);
				if (m_hexColorDict.ContainsKey(color))
				{
					continue;
				}
                m_hexColorDict.Add(color, hexColor);
			}
		}

        private static string Colored(string s, string hexColor)
        {
            string coloredStr = string.Format("<color={1}>{0}</color>", s, hexColor);
            return coloredStr;
        }

        private static string ColorToHexColor(Color32 c)
        {
            string hexColor = string.Format("#{0}{1}{2}", c.r.ToString("x2"), c.g.ToString("x2"), c.b.ToString("x2"));
            return hexColor;
        }
	}
}